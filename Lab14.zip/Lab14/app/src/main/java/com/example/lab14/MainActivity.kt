package com.example.lab14

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.lab14.databinding.ActivityMainBinding // 引入 Binding 類別
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    // 1. 使用 View Binding
    private lateinit var binding: ActivityMainBinding

    // 定義權限請求代碼常數
    private val LOCATION_PERMISSION_REQUEST_CODE = 0

    // 封裝權限檢查屬性，讓程式碼更乾淨
    private val isLocationPermissionGranted: Boolean
        get() = ActivityCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 初始化 View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 設定邊緣間距 (使用 binding.main)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        loadMap()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            // 使用 all 檢查是否所有權限都通過
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                loadMap()
            } else {
                finish()
            }
        }
    }

    override fun onMapReady(map: GoogleMap) {
        if (isLocationPermissionGranted) {
            setupMapFeatures(map)
        } else {
            // 請求權限
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    // 將地圖設定邏輯抽離，讓 onMapReady 更乾淨
    private fun setupMapFeatures(map: GoogleMap) {
        // 顯示目前位置
        try {
            map.isMyLocationEnabled = true
        } catch (e: SecurityException) {
            e.printStackTrace()
        }

        // 2. 使用 apply 優化 Marker 加入流程
        // 標記：台北101
        map.addMarker(MarkerOptions().apply {
            position(LatLng(25.033611, 121.565000))
            title("台北101")
            draggable(true)
        })

        // 標記：台北車站
        map.addMarker(MarkerOptions().apply {
            position(LatLng(25.047924, 121.517081))
            title("台北車站")
            draggable(true)
        })

        // 繪製線段
        val polylineOpt = PolylineOptions().apply {
            add(LatLng(25.033611, 121.565000))
            add(LatLng(25.032435, 121.534905))
            add(LatLng(25.047924, 121.517081))
            color(Color.BLUE)
            width(10f)
        }
        map.addPolyline(polylineOpt)

        // 移動視角
        map.moveCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(25.035, 121.54), 13f
            )
        )
    }

    private fun loadMap() {
        // 使用 supportFragmentManager 尋找 Fragment，並透過轉型確認
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.mapFragment) as? SupportMapFragment
        mapFragment?.getMapAsync(this)
    }
}